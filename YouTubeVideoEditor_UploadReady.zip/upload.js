
// Carregar a biblioteca do Google API
function start() {
  gapi.load("client:auth2", initClient);
}

function initClient() {
  gapi.client.init({
    apiKey: "", // Não obrigatório para OAuth2
    clientId: "401290690350-4auhol395vh4v5eujvr0dbj1a64p2oj2.apps.googleusercontent.com",
    discoveryDocs: ["https://www.googleapis.com/discovery/v1/apis/youtube/v3/rest"],
    scope: "https://www.googleapis.com/auth/youtube.upload"
  }).then(function () {
    console.log("GAPI client loaded for API");
  });
}

// Autenticar e enviar vídeo simulado
function authenticateAndUpload() {
  gapi.auth2.getAuthInstance().signIn().then(function () {
    alert("Login realizado. Aqui você poderá enviar o vídeo via API.");
    // Aqui você colocaria a lógica de upload real com FormData e vídeos renderizados
  });
}

// Iniciar após carregar a API
window.onload = function () {
  var s = document.createElement("script");
  s.src = "https://apis.google.com/js/api.js";
  s.onload = start;
  document.head.appendChild(s);
};
